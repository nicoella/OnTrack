<?php
$link = mysqli_connect("localhost", "root", "Nicolesupercool6969!!!!", "database");
?>